# Pharmacy Price Hub (Android) v0.2 — offline-first prototype

This Android project wraps the original application in an offline WebView. It is source code, **not a compiled APK**.

## What it does
- Search brand/generic names (including names typed in Arabic), edit product names, strength, pack, and categories.
- Add and edit suppliers, record sale/purchase/wholesale prices in LYD, and compare supplier prices.
- Keep dated price history when entering new price records.
- **Bulk import with just two columns**: `Drug name | Price`. Defaults: `My Pharmacy`, type `sale`.
- Also supports 3 columns (`Drug | Supplier | Price`), 4 (`Drug | Supplier | Type | Price`), and full 10/11/12/13-column tab- or pipe-separated sheets.
- Preview and validate bulk rows before import; all invalid rows must be fixed first.
- Backup all records to JSON, restore from the Android system document picker, export a TSV price sheet.

## Privacy and source data
No initial medication prices are bundled. The original 273-record Sept 16, 2026 import is a **separate, unverified historical JSON** file. It can be restored on-device through `Restore JSON (Android)` within `Data`. **Restore REPLACES the local database**. Take a backup before restoration; use the bulk importer to APPEND prices instead.

## Build an APK (Android Studio)
Open the unzipped project in Android Studio, allow Gradle sync, and choose `Build > Build APK(s)` or `./gradlew assembleDebug` after setting up a Gradle wrapper. This source ZIP intentionally lacks a prebundled Gradle wrapper JAR. The GitHub Actions workflow uses an installed Gradle 8.9 instead.

## Build an APK (GitHub Actions)
Upload the extracted source tree into a repository, preserving `.github/workflows/build-android.yml`, and run `Actions > Build offline Android APK`. A debug APK is uploaded as a workflow artifact.

**Simpler GitHub web upload for mobile**: upload `PharmacyPriceHub-Android-Source.zip` to the repository ROOT (not a folder). Then create a new repository file at `.github/workflows/build-from-zip.yml` by pasting the content from `build-from-zip.yml` provided separately. Run `Actions > Build Android APK from ZIP`. It unzips the source and builds the project.

## Safety and limits
- This prototype has **not been compiled, instrumented, audited, or tested on an Android phone**. Product pricing is not medical or dispensing advice.
- No internet permission. Local database can be lost upon uninstall or clearing app storage. Keep separate JSON backups.
- The GitHub repository should be PRIVATE where possible. Never upload private price datasets to a public repository.
- Debug APKs are meant for testing; release signing, multi-device sync, and robust automated test coverage are not yet implemented.
