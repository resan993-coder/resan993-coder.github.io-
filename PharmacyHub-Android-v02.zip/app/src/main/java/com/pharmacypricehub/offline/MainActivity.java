package com.pharmacypricehub.offline;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.annotation.SuppressLint;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
 private WebView web; private String pendingName="backup.json", pendingMime="application/json", pendingText="";
 private static final String ORIGIN="https://appassets.androidplatform.net/";
 @SuppressLint("SetJavaScriptEnabled") @Override public void onCreate(Bundle state){super.onCreate(state);
 web=new WebView(this); setContentView(web);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
 web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
 web.addJavascriptInterface(new Bridge(),"AndroidBridge");web.setWebChromeClient(new WebChromeClient());
 web.setWebViewClient(new WebViewClient(){
 @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
 Uri uri=req.getUrl();if("appassets.androidplatform.net".equals(uri.getHost()) && "/index.html".equals(uri.getPath())){
 try{return new WebResourceResponse("text/html","UTF-8",getAssets().open("index.html"));}catch(Exception e){return null;}}
 return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",java.util.Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
 @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return !ORIGIN.equals(req.getUrl().toString());}
 });web.loadUrl(ORIGIN+"index.html");}
 public class Bridge{
 @JavascriptInterface public void saveFile(String name,String mime,String text){runOnUiThread(()->{pendingName=name;pendingMime=mime;pendingText=text;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,2);});}
 @JavascriptInterface public void pickBackup(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,1);});}
 }
 @Override protected void onActivityResult(int req,int code,Intent data){super.onActivityResult(req,code,data);if(code!=RESULT_OK||data==null||data.getData()==null)return;
 try {if(req==1){ByteArrayOutputStream b=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(data.getData())){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){b.write(buf,0,n);if(b.size()>12*1024*1024)throw new IOException("Backup larger than 12 MB");}}String json=b.toString("UTF-8");web.evaluateJavascript("window.restoreFromNative("+JSONObject.quote(json)+")",null);}
 else if(req==2){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(pendingText.getBytes(StandardCharsets.UTF_8));}pendingText="";}}
 catch(Exception ex){new android.app.AlertDialog.Builder(this).setMessage("File operation failed: "+ex.getMessage()).setPositiveButton("OK",null).show();}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}